<?php
/* Smarty version 3.1.40, created on 2022-04-15 08:04:23
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/view_article.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62595f47e2c3c7_10327353',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'f3fb8a3aa4226b1277936ce5da43854069b848fc' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/view_article.tpl',
      1 => 1650024253,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62595f47e2c3c7_10327353 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_40623403562595f47e2a286_04407269', "content");
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./layout.tpl");
}
/* {block "content"} */
class Block_40623403562595f47e2a286_04407269 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_40623403562595f47e2a286_04407269',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>




    <div class="mx-auto mb-3" style="width: 800px">

        <a class="btn btn-primary my-3" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
client/kb/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Back to the List'];?>
</a>

        <div class="card">

            <div class="card-body">

                <h1 class="text-center mb-3"> <?php echo $_smarty_tpl->tpl_vars['article']->value->title;?>
 </h1>
                <p>
                    <?php echo $_smarty_tpl->tpl_vars['article']->value->description;?>

                </p>


            </div>

        </div>



    </div>


<?php
}
}
/* {/block "content"} */
}
