<?php
/* Smarty version 3.1.40, created on 2022-04-15 15:11:19
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/home.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6259c3575806c8_65306223',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'e69e92c48592bb5ae9f8a772d94ffb4a4bb6520a' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/home.tpl',
      1 => 1650049876,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6259c3575806c8_65306223 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_4463530056259c35757c954_48452630', "content");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./layout.tpl");
}
/* {block "content"} */
class Block_4463530056259c35757c954_48452630 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_4463530056259c35757c954_48452630',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <section>
        <div class="container">

            <div class="my-5">
                <h2 class="text-center mb-5">Products & Offers</h2>
            </div>

            <div class="row justify-content-start voice-plan-container">

                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['groups']->value, 'group');
$_smarty_tpl->tpl_vars['group']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->do_else = false;
?>

                    <div class="col-md-3 col-xs">
                        <a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
client/items/<?php echo $_smarty_tpl->tpl_vars['group']->value->slug;?>
/" class="m-3">
                            <div class="card">
                                <div class="card-body text-center">
                                    <h5><?php echo $_smarty_tpl->tpl_vars['group']->value->name;?>
</h5>
                                </div>
                            </div>
                        </a>
                    </div>

                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>


            </div>
        </div>
    </section>

<?php
}
}
/* {/block "content"} */
}
