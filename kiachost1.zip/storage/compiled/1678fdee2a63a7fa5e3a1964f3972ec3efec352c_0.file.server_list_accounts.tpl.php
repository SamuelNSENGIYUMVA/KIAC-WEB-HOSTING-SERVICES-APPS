<?php
/* Smarty version 3.1.40, created on 2022-12-10 10:25:31
  from 'C:\wamp64\www\kiachost\ui\theme\default\hostbilling\admin\server_list_accounts.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6394a4ebb5e191_37586974',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1678fdee2a63a7fa5e3a1964f3972ec3efec352c' => 
    array (
      0 => 'C:\\wamp64\\www\\kiachost\\ui\\theme\\default\\hostbilling\\admin\\server_list_accounts.tpl',
      1 => 1650354362,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6394a4ebb5e191_37586974 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_6570988066394a4eb9c9fe4_96863198', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_9399677016394a4ebb58326_11478253', 'script');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['layouts_admin']->value));
}
/* {block "content"} */
class Block_6570988066394a4eb9c9fe4_96863198 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_6570988066394a4eb9c9fe4_96863198',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="row">
                        <div class="col">
                            <h3><?php echo $_smarty_tpl->tpl_vars['_L']->value['List Accounts'];?>
</h3>
                        </div>
                        <div class="col text-end">
                            <?php if ($_smarty_tpl->tpl_vars['server']->value->type == 'cpanel') {?>
                                <button id="btn_sync_accounts" class="btn btn-primary"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Sync Accounts'];?>
</button>
                            <?php }?>
                        </div>
                    </div>
                    <div class="hr-line-dashed"></div>
                    <?php if ($_smarty_tpl->tpl_vars['errors']->value) {?>
                        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['errors']->value, 'value', false, 'key');
$_smarty_tpl->tpl_vars['value']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->do_else = false;
?>
                            <div class="alert alert-danger">
                                <?php echo $_smarty_tpl->tpl_vars['value']->value;?>

                            </div>
                        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        <?php } else { ?>

                        <?php if (count($_smarty_tpl->tpl_vars['accounts']->value) > 0) {?>
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th><?php echo __('Domain');?>
</th>
                                    <th><?php echo __('Plan');?>
</th>
                                    <th><?php echo __('Email');?>
</th>
                                    <th><?php echo __('Disk Used');?>
</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['accounts']->value, 'account');
$_smarty_tpl->tpl_vars['account']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['account']->value) {
$_smarty_tpl->tpl_vars['account']->do_else = false;
?>
                                    <tr>
                                        <td>
                                            <?php if (!empty($_smarty_tpl->tpl_vars['account']->value['domain'])) {?>
                                                <strong><?php echo $_smarty_tpl->tpl_vars['account']->value['domain'];?>
</strong>
                                            <?php }?>
                                        </td>
                                        <td>
                                            <?php if (!empty($_smarty_tpl->tpl_vars['account']->value['plan'])) {?>
                                                <?php echo $_smarty_tpl->tpl_vars['account']->value['plan'];?>

                                            <?php }?>
                                        </td>
                                        <td>
                                            <?php if (!empty($_smarty_tpl->tpl_vars['account']->value['email'])) {?>
                                                <?php echo $_smarty_tpl->tpl_vars['account']->value['email'];?>

                                            <?php }?>
                                        </td>
                                        <td>
                                            <?php if (!empty($_smarty_tpl->tpl_vars['account']->value['diskused'])) {?>
                                                <?php echo $_smarty_tpl->tpl_vars['account']->value['diskused'];?>

                                            <?php }?>
                                        </td>
                                    </tr>
                                <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                                </tbody>
                            </table>
                            <?php } else { ?>
                            <p>No data available.</p>
                        <?php }?>


                    <?php }?>
                </div>
            </div>
        </div>
    </div>

<?php
}
}
/* {/block "content"} */
/* {block 'script'} */
class Block_9399677016394a4ebb58326_11478253 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_9399677016394a4ebb58326_11478253',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>

        $(function () {

            let $btn_sync_accounts = $('#btn_sync_accounts');
            $btn_sync_accounts.on('click',function (event) {
                event.preventDefault();

                $btn_sync_accounts.prop('disabled',true);

                $.post(base_url + 'hostbilling/sync-accounts/', {
                    id: <?php echo $_smarty_tpl->tpl_vars['server']->value->id;?>

            })
                .done(function (data) {
                    $btn_sync_accounts.prop('disabled',false);
                    window.location = base_url + 'hostbilling/orders/';
                }).fail(function(data) {
                $btn_sync_accounts.prop('disabled',false);
                let errors = $.parseJSON(data.responseText);
                $.each(errors, function(key, value) {
                    toastr.error(value);
                });
            });

        });

        });


    <?php echo '</script'; ?>
>


<?php
}
}
/* {/block 'script'} */
}
