<?php
/* Smarty version 3.1.40, created on 2022-04-15 08:06:14
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/domain_register.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62595fb6db9662_26735828',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '36a4b9e8ea98cab583696bc3696288c8a4c6280d' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/domain_register.tpl',
      1 => 1650024325,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62595fb6db9662_26735828 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./layout.tpl");
}
}
