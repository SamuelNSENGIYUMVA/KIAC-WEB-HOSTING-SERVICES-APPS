<?php
define('DB_HOST', 'localhost'); # Database Host
define('DB_PORT', ''); # Database Port. Keep it blank if you are un sure.
define('DB_USER', 'root'); # Database Username
define('DB_PASSWORD', 'root'); # Database Password
define('DB_NAME', 'a'); # Database Name
define('APP_URL', 'http://www.example.com'); # Application URL.
#Please include http and do not use trailing slash after the url. For example use in this format- http://www.example.com Or http://www.example.com/finance
define('APP_STAGE', 'Live'); # Change Live to Dev to enable Debug