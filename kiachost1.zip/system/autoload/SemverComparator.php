<?php
class SemverComparator extends Composer\Semver\Comparator
{
}
