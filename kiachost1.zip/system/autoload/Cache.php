<?php
class Cache
{
    public static function init()
    {
        $container = new Container();
    }
}
