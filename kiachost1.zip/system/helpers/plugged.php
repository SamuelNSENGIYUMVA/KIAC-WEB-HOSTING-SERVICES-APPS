<?php
$ui->assign('admin_extra_nav', $admin_extra_nav);
$ui->assign('client_extra_nav', $client_extra_nav);
$ui->assign('sub_menu_admin', $sub_menu_admin);
$ui->assign('plugin_ui_header_admin', $plugin_ui_header_admin);
$ui->assign('plugin_ui_header_admin_css', $plugin_ui_header_admin_css);
$ui->assign('plugin_ui_header_client', $plugin_ui_header_client);
$ui->assign('plugin_ui_header_client_css', $plugin_ui_header_client_css);
