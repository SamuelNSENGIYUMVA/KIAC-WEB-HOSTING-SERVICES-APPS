<?php
/* Smarty version 3.1.40, created on 2022-04-15 07:57:28
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/whois.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_62595da8e1cbf7_83486704',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6ef98cc277667887ad12d606b8853a4205458376' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/whois.tpl',
      1 => 1650023847,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_62595da8e1cbf7_83486704 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "./layout.tpl");
}
}
