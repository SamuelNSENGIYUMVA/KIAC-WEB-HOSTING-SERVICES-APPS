<?php
/* Smarty version 3.1.40, created on 2022-12-10 10:13:03
  from 'C:\wamp64\www\kiachost\ui\theme\default\hostbilling\admin\choose_server_type.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6394a1ffe020a1_48940232',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1c1ce153d0ad8146cdf91e3484b281f83856a8cc' => 
    array (
      0 => 'C:\\wamp64\\www\\kiachost\\ui\\theme\\default\\hostbilling\\admin\\choose_server_type.tpl',
      1 => 1650354362,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6394a1ffe020a1_48940232 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_11475008536394a1ffddee19_31869921', "content");
?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10614735456394a1ffe004c1_81465047', 'script');
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, ((string)$_smarty_tpl->tpl_vars['layouts_admin']->value));
}
/* {block "content"} */
class Block_11475008536394a1ffddee19_31869921 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_11475008536394a1ffddee19_31869921',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <h1><?php echo $_smarty_tpl->tpl_vars['_L']->value['Choose Server Type'];?>
</h1>
    <div class="hr-line-dashed"></div>

    <div class="row">
        <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['available_server_types']->value, 'value', false, 'key');
$_smarty_tpl->tpl_vars['value']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->do_else = false;
?>
            <div class="col-md-3">
                <a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
hostbilling/server/0/<?php echo $_smarty_tpl->tpl_vars['key']->value;?>
">
                    <div class="card">
                        <div class="card-body">
                            <h2><?php echo $_smarty_tpl->tpl_vars['value']->value['name'];?>
</h2>
                        </div>
                    </div>
                </a>
            </div>
        <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
    </div>



<?php
}
}
/* {/block "content"} */
/* {block 'script'} */
class Block_10614735456394a1ffe004c1_81465047 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_10614735456394a1ffe004c1_81465047',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php echo '<script'; ?>
>

    <?php echo '</script'; ?>
>


<?php
}
}
/* {/block 'script'} */
}
