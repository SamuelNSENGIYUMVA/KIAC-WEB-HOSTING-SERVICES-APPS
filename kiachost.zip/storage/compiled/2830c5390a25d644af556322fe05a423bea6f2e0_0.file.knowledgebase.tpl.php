<?php
/* Smarty version 3.1.40, created on 2022-12-12 14:06:59
  from 'C:\wamp64\www\kiachost\ui\theme\default\hostbilling\client\knowledgebase.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_639719635db181_96188148',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2830c5390a25d644af556322fe05a423bea6f2e0' => 
    array (
      0 => 'C:\\wamp64\\www\\kiachost\\ui\\theme\\default\\hostbilling\\client\\knowledgebase.tpl',
      1 => 1650354362,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_639719635db181_96188148 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_207395796463971963532073_33270368', "content");
?>


<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "hostbilling/layouts/client.tpl");
}
/* {block "content"} */
class Block_207395796463971963532073_33270368 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_207395796463971963532073_33270368',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <div class="card mx-auto" style="width: 800px">


        <div class="card-body">

            <h1 class="text-center"> <?php echo $_smarty_tpl->tpl_vars['_L']->value['Articles'];?>
 </h1>

            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['knowledgebases_group_relations']->value, 'value', false, 'key');
$_smarty_tpl->tpl_vars['value']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['key']->value => $_smarty_tpl->tpl_vars['value']->value) {
$_smarty_tpl->tpl_vars['value']->do_else = false;
?>

                <?php if (!empty($_smarty_tpl->tpl_vars['knowledgebases_groups']->value[$_smarty_tpl->tpl_vars['key']->value])) {?>
                    <h2 class="my-3"><?php echo $_smarty_tpl->tpl_vars['knowledgebases_groups']->value[$_smarty_tpl->tpl_vars['key']->value]->gname;?>
</h2>

                    <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['value']->value, 'kb_relation');
$_smarty_tpl->tpl_vars['kb_relation']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['kb_relation']->value) {
$_smarty_tpl->tpl_vars['kb_relation']->do_else = false;
?>
                        <?php if (!empty($_smarty_tpl->tpl_vars['knowledgebases']->value[$_smarty_tpl->tpl_vars['kb_relation']->value->kbid])) {?>
                            <p>
                                <a href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
client/view-article/<?php echo $_smarty_tpl->tpl_vars['kb_relation']->value->kbid;?>
/"><strong><?php echo $_smarty_tpl->tpl_vars['knowledgebases']->value[$_smarty_tpl->tpl_vars['kb_relation']->value->kbid]->title;?>
</strong></a>
                            </p>
                        <?php }?>
                    <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>

                <?php }?>

            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>





        </div>
    </div>


<?php
}
}
/* {/block "content"} */
}
