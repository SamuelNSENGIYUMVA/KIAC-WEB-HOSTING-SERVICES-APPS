<?php
/* Smarty version 3.1.40, created on 2022-04-15 15:55:27
  from '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/layout.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_6259cdaf546eb7_42850797',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c82bf4e26867bf761dd205d220c00ed1580549c2' => 
    array (
      0 => '/Users/razib/Documents/valet/business-suite/ui/theme/frontend/hosting_x/layout.tpl',
      1 => 1650052525,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6259cdaf546eb7_42850797 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, false);
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="description" content="<?php echo $_smarty_tpl->tpl_vars['config']->value['CompanyName'];?>
">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="msapplication-tap-highlight" content="no">
    <link rel="icon" href="<?php ob_start();
echo APP_URL;
$_prefixVariable1 = ob_get_clean();
echo $_prefixVariable1;?>
/storage/system/<?php echo get_or_default($_smarty_tpl->tpl_vars['config']->value,'icon-32','icon-32x32.png');?>
" sizes="32x32" />
    <link rel="icon" href="<?php ob_start();
echo APP_URL;
$_prefixVariable2 = ob_get_clean();
echo $_prefixVariable2;?>
/storage/system/<?php echo get_or_default($_smarty_tpl->tpl_vars['config']->value,'icon-192','icon-192x192.png');?>
" sizes="192x192" />
    <link rel="apple-touch-icon" href="<?php ob_start();
echo APP_URL;
$_prefixVariable3 = ob_get_clean();
echo $_prefixVariable3;?>
/storage/system/<?php echo get_or_default($_smarty_tpl->tpl_vars['config']->value,'icon-180','icon-180x180.png');?>
" />
    <meta name="msapplication-TileImage" content="<?php ob_start();
echo APP_URL;
$_prefixVariable4 = ob_get_clean();
echo $_prefixVariable4;?>
/storage/system/<?php echo get_or_default($_smarty_tpl->tpl_vars['config']->value,'icon-270','icon-270x270.png');?>
" />
    <title><?php echo $_smarty_tpl->tpl_vars['_title']->value;?>
</title>
    <link href="<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
frontend/hosting_x/css/theme.min.css?v=4" rel="stylesheet">
    <?php if ((isset($_smarty_tpl->tpl_vars['config']->value['header_scripts']))) {?>
        <?php echo $_smarty_tpl->tpl_vars['config']->value['header_scripts'];?>

    <?php }?>
    <?php echo '<script'; ?>
>
        var base_url = '<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
';
        var block_msg = '<div class="md-preloader text-center"><svg xmlns="http://www.w3.org/2000/svg" version="1.1" height="32" width="32" viewbox="0 0 75 75"><circle cx="37.5" cy="37.5" r="33.5" stroke-width="6"/></svg></div>';
    <?php echo '</script'; ?>
>
    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_17597075406259cdaf528fe0_41346840', 'head');
?>

</head>

<body>

<div id="hx-header" class="d-flex mx-auto flex-column"><!-- start header -->
    <div class="bg_overlay_header">
        <div class="bg-img-header-new-standard">&nbsp;</div>
    </div>
    <!-- Fixed navbar -->
    <nav id="hx-navbar-header" class="navbar navbar-expand-md fixed-header-layout">
        <div class="container main-header-hx-s">

            <a class="navbar-brand" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/dashboard/"><img src="<?php ob_start();
echo APP_URL;
$_prefixVariable5 = ob_get_clean();
echo $_prefixVariable5;?>
/storage/system/<?php ob_start();
echo $_smarty_tpl->tpl_vars['config']->value['logo_default'];
$_prefixVariable6 = ob_get_clean();
echo $_prefixVariable6;?>
" style="max-height: 35px;" alt="<?php ob_start();
echo $_smarty_tpl->tpl_vars['config']->value['CompanyName'];
$_prefixVariable7 = ob_get_clean();
echo $_prefixVariable7;?>
" /></a>

            <button class="navbar-toggle offcanvas-toggle menu-btn-span-bar ml-auto" data-toggle="offcanvas" data-target="#offcanvas-menu-home">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <div class="collapse navbar-collapse navbar-offcanvas" id="offcanvas-menu-home">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown <?php if ($_smarty_tpl->tpl_vars['selected_navigation']->value == 'dashboard') {?>active<?php }?>">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/home/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Home'];?>
</a>
                    </li>

                    <li class="nav-item dropdown">
                        <a class="nav-link" role="button" id="menu-items-list" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Place New Order'];?>
</a>
                        <ul class="dropdown-menu hx-dropdown-header">
                            <?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['groups']->value, 'group');
$_smarty_tpl->tpl_vars['group']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['group']->value) {
$_smarty_tpl->tpl_vars['group']->do_else = false;
?>
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
client/items/<?php echo $_smarty_tpl->tpl_vars['group']->value->slug;?>
/"><?php echo $_smarty_tpl->tpl_vars['group']->value->name;?>
</a></li>
                            <?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
                        </ul>
                    </li>

                    <?php if (!empty($_smarty_tpl->tpl_vars['user']->value)) {?>

                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" role="button" id="header-help-drop-down" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['_L']->value['My Orders'];?>
</a>
                            <ul class="dropdown-menu hx-dropdown-header" aria-labelledby="header-help-drop-down">
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/domain-orders/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Domain Orders'];?>
</a></li>
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/hosting-orders/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Hosting Orders'];?>
</a></li>
                            </ul>
                        </li>

                    <?php }?>

                    <li class="nav-item dropdown">
                        <a class="nav-link" href="#" role="button" id="header-help-drop-down" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Domains'];?>
</a>
                        <ul class="dropdown-menu hx-dropdown-header" aria-labelledby="header-help-drop-down">
                            <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/whois/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['WHOIS Lookup'];?>
</a></li>
                            <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/domain-register/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Register Domain'];?>
</a></li>
                        </ul>
                    </li>



                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/kb/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Knowledgebase'];?>
</a>
                    </li>

                    <?php echo $_smarty_tpl->tpl_vars['client_extra_nav']->value[3];?>


                    <?php if (!empty($_smarty_tpl->tpl_vars['user']->value)) {?>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" role="button" id="header-help-drop-down" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Billing'];?>
</a>
                            <ul class="dropdown-menu hx-dropdown-header" aria-labelledby="header-help-drop-down">
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/invoices/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Invoices'];?>
</a></li>
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/quotes/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Quotes'];?>
</a></li>
                            </ul>
                        </li>
                    <?php if ($_smarty_tpl->tpl_vars['config']->value['support']) {?>
                        <li class="nav-item dropdown">
                            <a class="nav-link" href="#" role="button" id="header-help-drop-down" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Support'];?>
</a>
                            <ul class="dropdown-menu hx-dropdown-header" aria-labelledby="header-help-drop-down">
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/downloads/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Documents'];?>
</a></li>
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/tickets/new/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Open New Ticket'];?>
</a></li>
                                <li><a class="dropdown-item" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/tickets/all/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Tickets'];?>
</a></li>
                            </ul>
                        </li>
                    <?php }?>

                    <?php }?>


                </ul>
            </div>
            <ul class="header-user-info-hx">

                <?php if (!empty($_smarty_tpl->tpl_vars['user']->value)) {?>
                    <li class="dropdown"><a id="header-login-dropdown" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/login/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Account'];?>
</a>
                    </li>
                <?php } else { ?>
                    <li class="dropdown"><a id="header-login-dropdown" href="<?php echo $_smarty_tpl->tpl_vars['_url']->value;?>
client/dashboard/"><?php echo $_smarty_tpl->tpl_vars['_L']->value['Dashboard'];?>
</a>
                    </li>
                <?php }?>


            </ul>
        </div>
    </nav>
    <div class="mt-auto header-top-height"></div>

    <?php if ($_smarty_tpl->tpl_vars['page_name']->value == 'home' || $_smarty_tpl->tpl_vars['page_name']->value == 'whois') {?>

        <main class="container mb-auto">
            <div class="carousel carousel-main">
                <div class="carousel-cell">
                    <h3 class="mt-3 main-header-text-title">

                        Start your domain name search <small>we make it simple to find the right domain</small></h3>
                    <form action="<?php echo $_smarty_tpl->tpl_vars['base_url']->value;?>
client/whois-post/" id="domain-search-header" class="col-md-6">
                        <i class="fas fa-globe"></i>
                        <input type="text" placeholder="search for you domain now" id="domain_name" name="domain_name">
                        <span class="inline-button-domain-order">
                  	  <button data-toggle="tooltip" data-placement="left" title="search" id="search-btn" type="submit" name="submit" value="Search"><i class="fas fa-search"></i></button>
                  	  </span>
                    </form>

                    <div class="row my-3">
                        <div class="col-md-12" id="domain_search_result" style="display: none;">

                        </div>
                    </div>

                    <div class="owl-theme owl-domain-prices-previw col-md-7">
                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/com.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/net.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/org.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/store.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/net.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/store.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
                  	        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
                  	        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/com.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
	                        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
	                        </span>
                        </div>

                        <div class="domain-name-classes item">
                            <div class="domain-img"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/net.png" alt="" /></div>
                            <span class="price">$2.99</span>
                            <span class="features-domains">
                           	<a data-toggle="tooltip" data-placement="right" title="on sale"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Time.svg" alt="" /></a>
	                        <a data-toggle="tooltip" data-placement="right" title="secure"><img src="<?php echo APP_URL;?>
/ui/theme/frontend/hosting_x/img/Locked.svg" alt="" /></a>
	                        </span>
                        </div>
                    </div>

                </div>

                <div class="carousel-cell">
                    <div class="row hosting-header-slider-cell">
                        <div class="col-md-6">
                            <h3 class="mt-3 main-header-text-title">
                                <i class="circle-sub-title-header-slider">the best web hosting provider</i>
                                Perfect Plans For Getting <br>Started
                                <small>order yours now</small>
                            </h3>
                            <p class="text-sub-title-header-slider">Quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.</p>
                            <a class="btn-sub-title-header-slider" href="dedicated.html">start now</a>
                        </div>
                        <div class="col-md-6 text-center">
                            <img class="hosting-header-slider-cell-img" src="img/header/slider/header-bg.png" alt="" />
                        </div>
                    </div>
                </div>
            </div>

            <nav class="nav-header-chage nav--shamso carousel-nav">
                <button class="nav__item nav__item--current carousel-cell" aria-label="Item 1"><span class="nav__item-title">Domains</span></button>
                <button class="nav__item carousel-cell" aria-label="Item 2"><span class="nav__item-title">Hosting</span></button>
            </nav>

        </main>

        <?php } else { ?>



    <?php }?>

    <div class="mt-auto"></div>
</div><!-- end header -->



<?php if ((isset($_smarty_tpl->tpl_vars['notify']->value))) {
echo $_smarty_tpl->tpl_vars['notify']->value;
}?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_19990330636259cdaf544a35_45872013', "content");
?>



<section class="home-ads-section">
    <h1>12% OFF for all Web hosting services</h1>
</section>


<section class="footer-section-banner">
    <div class="container">
        <div class="row free-trial-footer-banner">
            <div class="col-md-8">
                <h5 class="free-trial-footer-banner-title">join now and have free month of deluxe hosting</h5>
                <p class="free-trial-footer-banner-text">We offers a free month of service for new customers.* Sign up for your trial offer and instantly have deluxe hosting in your account with free domain included.</p>
            </div>

            <div class="col-md-4 free-trial-footer-links d-flex mx-auto flex-column">
                <div class="mb-auto"></div>
                <div class="mb-auto">
                    <a class="sign-btn" href="signup.html">sign up</a>
                    <a class="log-btn" href="signin.html">log in</a>
                </div>
                <div class="mt-auto"></div>
            </div>
        </div>
    </div>
</section>

<section class="footer-section">
    <div class="container">
        <div class="row">
            <div class="col-md-9 quiq-links-footer">
                <h5 class="quiq-links-footer-title">Quick Links</h5>
                <div class="row">
                    <ul class="col-md-6 quiq-links-footer-ul">
                        <li><a href="#">our company announcements</a></li>
                        <li><a href="#">Knowledgebase</a></li>
                        <li><a href="#">Downloads</a></li>
                        <li><a href="#">Network Status</a></li>
                        <li><a href="#">My Support Tickets</a></li>
                        <li><a href="#">Register a New Domain</a></li>
                        <li><a href="#">Transfer New Domain</a></li>
                        <li><a href="#">Software Products</a></li>
                        <li><a href="#">Dedicated Hosting</a></li>
                    </ul>

                    <ul class="col-md-6 quiq-links-footer-ul">
                        <li><a href="#">Contact Us</a></li>
                        <li><a href="#">Network Status</a></li>
                        <li><a href="#">Forgot Password?</a></li>
                        <li><a href="#">Create an account with us</a></li>
                        <li><a href="#">Login to your account</a></li>
                        <li><a href="#">make a new payment</a></li>
                        <li><a href="#">Review & Checkout</a></li>
                        <li><a href="#">client area</a></li>
                        <li><a href="#">manage your account</a></li>
                    </ul>

                </div>
            </div>

            <div class="col-md-3">
                <h5 class="quiq-links-footer-title">secure and contact</h5>
                <p class="secure-img-footer-area">
                    <img src="img/footer/secure.png" alt="" />
                    <span>this is for demo reason only</span>
                </p>

                <div class="footer-contact-method">
                    <a href="#">
                        <span>email us :</span>
                        <b>support@hx.net</b>
                        <i class="fas fa-at"></i>
                    </a>

                    <a href="#">
                        <span>call us :</span>
                        <b>00123 45 67 89 91</b>
                        <i class="fas fa-phone"></i>
                    </a>
                </div>
            </div>
        </div>

        <div class="mr-tp-40 row justify-content-between footer-area-under">
            <div class="col-md-4">
                <a href="#"><img class="footer-logo-blue" src="img/header/logo-w-f.png" alt="" /></a>
                <div class="footer-social-icons">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-dribbble"></i></a>
                    <a href="#"><i class="fab fa-google"></i></a>
                </div>
            </div>

            <div class="col-md-4 row">
                <ul class="col-md-6 under-footer-ullist">
                    <li><a href="#">about us</a></li>
                    <li><a href="#">our services</a></li>
                </ul>
                <ul class="col-md-6 under-footer-ullist text-right">
                    <li><a href="#">privacy policy</a></li>
                    <li><a href="#">terms of sevice</a></li>
                </ul>
            </div>

        </div>

        <div class="row justify-content-between final-footer-area mr-tp-40">
            <div class="final-footer-area-text">
                © Copyright 2019 hx , made with love in ageria
            </div>

            <div class="footer-lang-changer">
                <div class="lang-changer-drop-up">
                    <a class="menu-btn-changer" role="button" id="dropupmenulagchanger" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" href="#"><i class="fas fa-globe-asia"></i> english</a>
                    <div class="dropdown-menu dropupmenulagchanger" aria-labelledby="dropupmenulagchanger">
                        <a class="dropdown-item" href="#">english</a>
                        <a class="dropdown-item" href="#">العربية</a>
                        <a class="dropdown-item" href="#">Español</a>
                        <a class="dropdown-item" href="#">Nederlands</a>
                        <a class="dropdown-item" href="#">Français</a>
                        <a class="dropdown-item" href="#">Dansk</a>
                        <a class="dropdown-item" href="#">Português</a>
                        <a class="dropdown-item" href="#">Deutsch</a>
                    </div>
                </div>

                <div class="lang-changer-drop-up">
                    <a class="menu-btn-changer" href="#"><img src="img/flags/usa.svg" alt="" /> united states</a>
                </div>
            </div>
        </div>
    </div>
</section>

<?php echo '<script'; ?>
 src="<?php echo $_smarty_tpl->tpl_vars['theme']->value;?>
frontend/hosting_x/js/theme.min.js?v=7"><?php echo '</script'; ?>
>

<?php echo '<script'; ?>
>

    $(function () {
        if(document.getElementById('domain-search-header')){
            let $form_domain_search = $('#domain-search-header');
            let $domain_search_result = $('#domain_search_result');
            let $domain_name = $('#domain_name');
            let $btn_domain_submit = $('#btn_domain_submit');
            $form_domain_search.on('submit',function (event) {
                event.preventDefault();
                $btn_domain_submit.prop('disabled',true);
                axios.post(base_url + 'client/whois-post',$form_domain_search.serialize()).then(function (response) {
                    $btn_domain_submit.prop('disabled',false);
                    $domain_search_result.show();
                    $domain_search_result.html('<div class="card"><div class="card-body">' + response.data + '</div></div>');
                }).catch(function (error) {

                    $btn_domain_submit.prop('disabled',false);

                    $.each(error.response.data, function(key, value) {
                        toastr.error(value);
                    });

                });

            });
        }
    });

<?php echo '</script'; ?>
>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_10325370216259cdaf5457c7_17920604', 'script');
?>


</body>

</html>
<?php }
/* {block 'head'} */
class Block_17597075406259cdaf528fe0_41346840 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head' => 
  array (
    0 => 'Block_17597075406259cdaf528fe0_41346840',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'head'} */
/* {block "content"} */
class Block_19990330636259cdaf544a35_45872013 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_19990330636259cdaf544a35_45872013',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block "content"} */
/* {block 'script'} */
class Block_10325370216259cdaf5457c7_17920604 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_10325370216259cdaf5457c7_17920604',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
}
}
/* {/block 'script'} */
}
