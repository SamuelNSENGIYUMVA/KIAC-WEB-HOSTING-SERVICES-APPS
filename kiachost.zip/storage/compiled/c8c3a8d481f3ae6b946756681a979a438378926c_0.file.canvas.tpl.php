<?php
/* Smarty version 3.1.40, created on 2022-12-12 14:34:23
  from 'C:\wamp64\www\kiachost\ui\theme\default\layouts\canvas.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.40',
  'unifunc' => 'content_63971fcfe85910_69349112',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c8c3a8d481f3ae6b946756681a979a438378926c' => 
    array (
      0 => 'C:\\wamp64\\www\\kiachost\\ui\\theme\\default\\layouts\\canvas.tpl',
      1 => 1650354362,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63971fcfe85910_69349112 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
if ((isset($_smarty_tpl->tpl_vars['config']->value['base_layout']))) {?>
    
    <?php } else { ?>
    
<?php }?>


<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_88406474463971fcfe7bba6_38805671', "head_extras_from_layout");
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_21005720963971fcfe7f429_72382557', "content_body");
?>



<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_130930291363971fcfe83a88_51585030', "script");
?>

<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, $_smarty_tpl->tpl_vars['config']->value['base_layout']);
$_smarty_tpl->inheritance->endChild($_smarty_tpl, "layouts/base.tpl");
}
/* {block "head_extras_from_layout"} */
class Block_88406474463971fcfe7bba6_38805671 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'head_extras_from_layout' => 
  array (
    0 => 'Block_88406474463971fcfe7bba6_38805671',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <style>
        .pristine-error.text-help {
            color: red;
        }
        @media (min-width: 992px){
            .clx-fixed-navigation:not(.clx-navigation-type-top):not(.nav-function-hidden):not(.nav-function-minify) .page-content-wrapper {
                padding-left: 0;
            }
        }
    </style>
<?php
}
}
/* {/block "head_extras_from_layout"} */
/* {block "content"} */
class Block_101533220963971fcfe80b19_84636415 extends Smarty_Internal_Block
{
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php
}
}
/* {/block "content"} */
/* {block "content_body"} */
class Block_21005720963971fcfe7f429_72382557 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content_body' => 
  array (
    0 => 'Block_21005720963971fcfe7f429_72382557',
  ),
  'content' => 
  array (
    0 => 'Block_101533220963971fcfe80b19_84636415',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>


    <?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_101533220963971fcfe80b19_84636415', "content", $this->tplIndex);
?>


<?php
}
}
/* {/block "content_body"} */
/* {block "script"} */
class Block_130930291363971fcfe83a88_51585030 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'script' => 
  array (
    0 => 'Block_130930291363971fcfe83a88_51585030',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>

    <?php echo '<script'; ?>
>
        $(function () {



        });
    <?php echo '</script'; ?>
>
<?php
}
}
/* {/block "script"} */
}
