<?php

$myCtrl = 'supplier';

require 'system/controllers/client.php';