# Language Files for Business Suite


https://www.cloudonex.com/business-suite/localization/
