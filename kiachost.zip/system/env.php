<?php
return [
    'cache' => [
        'default' => 'file',
        'stores' => [
            'file' => [
                'driver' => 'file',
                'path' => 'storage/cache/system',
            ],
        ],
    ],
    'filesystems' => [
        'default' => 'local',

        'disks' => [
            'local' => [
                'driver' => 'local',
                'root' => './',
            ],
        ],
    ],
    'system' => [
        'update_url' => 'https://www.cloudonex.com', # Changing this will break automatic update.
        'item_id' => 4472,
        'version' => '1.2.1',
    ],
];
