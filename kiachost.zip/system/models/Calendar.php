<?php
use Illuminate\Database\Eloquent\Model;

class Calendar extends Model
{
    protected $table = 'sys_events';
    public $timestamps = false;
}
