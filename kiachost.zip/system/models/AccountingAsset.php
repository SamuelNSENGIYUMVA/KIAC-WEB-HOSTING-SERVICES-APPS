<?php
use Illuminate\Database\Eloquent\Model;

class AccountingAsset extends Model
{
    protected $table = 'assets';
}