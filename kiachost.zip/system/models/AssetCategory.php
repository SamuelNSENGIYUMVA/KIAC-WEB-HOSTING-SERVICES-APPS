<?php
use Illuminate\Database\Eloquent\Model;

class AssetCategory extends Model
{

}