<?php
use Illuminate\Database\Eloquent\Model;

class AutomationTask extends Model
{
}
