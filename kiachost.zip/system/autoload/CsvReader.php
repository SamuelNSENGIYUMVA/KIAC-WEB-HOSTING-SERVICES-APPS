<?php

use League\Csv\Reader;

class CsvReader extends Reader
{
}
