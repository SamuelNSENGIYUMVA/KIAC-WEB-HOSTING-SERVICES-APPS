<?php

Class Response extends Symfony\Component\HttpFoundation\Response{

}