<?php

use Illuminate\Http\Client\Factory;

class Http extends Factory
{
}
