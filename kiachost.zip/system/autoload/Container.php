<?php
class Container extends \Illuminate\Container\Container
{
}
